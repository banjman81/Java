package com.bman.Controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.bman.Models.Answer;
import com.bman.Models.Question;
import com.bman.Models.Tag;
import com.bman.Service.AnswerService;
import com.bman.Service.QuestionService;
import com.bman.Service.TagService;

@Controller
public class QuestionController {
	private final QuestionService qService;
	private final TagService tService;
	private final AnswerService aService;
	
	public QuestionController(QuestionService qService, TagService tService, AnswerService aService) {
		this.qService = qService;
		this.tService = tService;
		this.aService = aService;
	}
	
	@RequestMapping("/questions")
	public String index(Model model) {
		List<Question> questions = qService.allQuestions();
		model.addAttribute("questions", questions);
		return "index.jsp";
	}
	
	@RequestMapping("/questions/new")
	public String newQuestion(@ModelAttribute("Question") Question question, @ModelAttribute("Tag") Tag tag) {
		return "newQuestion.jsp";
	}
	
	@RequestMapping("/question/{id}")
	public String showQuestion(@PathVariable("id") Long id, Model model, @ModelAttribute("answer") Answer answer) {
		Question question  = qService.findQuestion(id);
		model.addAttribute("question", question);
		return "question.jsp";
	}
	
	@PostMapping("/addanswer")
	public String addAnswer(@RequestParam("answer") String answer,@RequestParam("question") Long id, RedirectAttributes redirectAttributes) {
		Question question = qService.findQuestion(id);
		if(answer.length() < 2) {
			redirectAttributes.addFlashAttribute("answer_error","Invalid Answer!");
			return "redirect:/question/"+ id;
		}
		else {
			Answer ans = new Answer(answer, question);
			aService.addAnswer(ans);
			return "redirect:/question/"+ id;
		}
		
	}
	
	@PostMapping("/newquestion")
	public String addQuestion(@RequestParam("question") String question,  @RequestParam("tags") String tags,  RedirectAttributes redirectAttributes) {
		if(question.length() < 5) {
			redirectAttributes.addFlashAttribute("q_error","Question need to be at least 5 characters long");
			return "redirect:/questions/new";
		}
		else if(tags.length() == 0) {
			redirectAttributes.addFlashAttribute("t_error","Please enter a  tag");
			return "redirect:/questions/new";
		}
		Question newQuestion = new Question(question);
		List<Tag> qTags = newQuestion.getTags();
		String[] arrOfTags = tags.split(",");
		for(String tag:arrOfTags) {
			Tag tagInput = new Tag(tag);
			Tag tagData = tService.findTagByName(tag);
			if (tagData == null) {
				Tag newTag = tService.addTag(tagInput);
				qTags.add(newTag);
			}
			else {
				qTags.add(tagData);
			}
			newQuestion.setTags(qTags);
		}
		qService.addQuestion(newQuestion);
		return "redirect:/questions";
	}
}
