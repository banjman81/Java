package com.bman.Controllers;

import org.springframework.stereotype.Controller;

import com.bman.Service.TagService;

@Controller
public class TagController {
	private final TagService tService;
	
	public TagController(TagService tService) {
		this.tService  = tService;
	}
}
