package com.bman.Controllers;

import org.springframework.stereotype.Controller;

import com.bman.Service.AnswerService;

@Controller
public class AnswerController {
	private final AnswerService aService;
	
	public AnswerController(AnswerService aService) {
		this.aService = aService;
	}
	
	
}
