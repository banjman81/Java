package com.bman.Repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.bman.Models.Question;

@Repository
public interface QuestionReposiotry extends CrudRepository<Question, Long> {
	List<Question> findAll();
}
