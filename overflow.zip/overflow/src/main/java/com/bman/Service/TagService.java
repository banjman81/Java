package com.bman.Service;

import org.springframework.stereotype.Service;

import com.bman.Models.Tag;
import com.bman.Repository.TagRepository;

@Service
public class TagService {
	private final TagRepository tRepo;
	
	public TagService(TagRepository tRepo) {
		this.tRepo = tRepo;
	}
	
	public Tag findTagByName(String name) {
		return tRepo.findTagByName(name);
	}

	public Tag addTag(Tag tag) {
		return tRepo.save(tag);
	}
}
