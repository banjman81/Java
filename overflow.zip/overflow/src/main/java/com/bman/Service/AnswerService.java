package com.bman.Service;

import javax.validation.Valid;

import org.springframework.stereotype.Service;

import com.bman.Models.Answer;
import com.bman.Repository.AnswerRepository;

@Service
public class AnswerService {
	private final AnswerRepository aRepo;
	
	public AnswerService(AnswerRepository aRepo) {
		this.aRepo = aRepo;
	}

	public Answer addAnswer(@Valid Answer answer) {
		return aRepo.save(answer);
	}
}
