package com.bman.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.bman.Models.Question;
import com.bman.Repository.QuestionReposiotry;

@Service
public class QuestionService {
	private final QuestionReposiotry qRepo;
	
	public QuestionService(QuestionReposiotry qRepo) {
		this.qRepo = qRepo;
	}
	
	public Question addQuestion(Question newQuestion) {
		return qRepo.save(newQuestion);
	}

	public List<Question> allQuestions() {
		// TODO Auto-generated method stub
		return qRepo.findAll();
	}

	public Question findQuestion(Long id) {
		Optional<Question> question =  qRepo.findById(id);
		if(question.isPresent()) {
			return question.get();
		}
		return null;
	}


}
