package com.bman.Repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.bman.Models.Category;

@Repository
public interface CategoryRepository extends CrudRepository <Category, Long> {
	List<Category> findAll();

	Category findByNameContaining(String name);
}
