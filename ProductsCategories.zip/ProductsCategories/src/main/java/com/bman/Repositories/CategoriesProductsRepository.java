package com.bman.Repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.bman.Models.CategoriesProduct;

@Repository
public interface CategoriesProductsRepository extends CrudRepository<CategoriesProduct, Long> {
	List<CategoriesProduct> findAll();
}
