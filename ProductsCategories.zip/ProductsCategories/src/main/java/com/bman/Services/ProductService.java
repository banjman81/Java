package com.bman.Services;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.stereotype.Service;

import com.bman.Models.Product;
import com.bman.Repositories.ProductRepository;

@Service
public class ProductService {
	private final ProductRepository productRepository;
	
	public ProductService(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}
	
	public List<Product> allCategory(){
		return  productRepository.findAll();
	}

	public Product addProduct(@Valid Product product) {
		// TODO Auto-generated method stub
		return productRepository.save(product);
	}

	public Product search(String name) {
		// TODO Auto-generated method stub
		return productRepository.findByNameContaining(name);
	}

	public Product findProduct(Long id) {
		// TODO Auto-generated method stub
		Optional<Product> pro = productRepository.findById(id);
        if(pro.isPresent()) {
            return pro.get();
        } else {
            return null;
        }
	}
}
