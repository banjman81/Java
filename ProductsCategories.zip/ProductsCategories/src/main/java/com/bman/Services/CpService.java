package com.bman.Services;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Service;

import com.bman.Models.CategoriesProduct;
import com.bman.Repositories.CategoriesProductsRepository;

@Service
public class CpService {
	private final CategoriesProductsRepository cpRepository;
	
	public CpService(CategoriesProductsRepository cpRepository) {
		this.cpRepository = cpRepository;
	}
	public  List<CategoriesProduct> allCP(){
		return cpRepository.findAll();
	}
	
	public @Valid CategoriesProduct cpLink(@Valid CategoriesProduct categories) {
		// TODO Auto-generated method stub
		return cpRepository.save(categories);
	}
}
