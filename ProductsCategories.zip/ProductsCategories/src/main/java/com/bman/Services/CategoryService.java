package com.bman.Services;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.stereotype.Service;

import com.bman.Models.Category;
import com.bman.Repositories.CategoryRepository;

@Service
public class CategoryService {
	private final CategoryRepository categoryRepository;
	
	public CategoryService(CategoryRepository categoryRepository) {
		this.categoryRepository = categoryRepository;
	}
	
	public List<Category> allCategory(){
		return  categoryRepository.findAll();
	}

	public Category addCategory(@Valid Category category) {
		// TODO Auto-generated method stub
		return categoryRepository.save(category);
	}

	public Category search(String name) {
		// TODO Auto-generated method stub
		return categoryRepository.findByNameContaining(name);
	}

	public Category findCategory(Long id) {
		// TODO Auto-generated method stub
		Optional<Category> pro = categoryRepository.findById(id);
        if(pro.isPresent()) {
            return pro.get();
        } else {
            return null;
        }
	}
}
