package com.bman.Controllers;

import org.springframework.stereotype.Controller;

import com.bman.Services.CpService;

@Controller
public class CpController {
	private final CpService cpService;
	
	public CpController(CpService cpService) {
		this.cpService = cpService;
	}
	
	
}
