package com.bman.Controllers;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bman.Models.CategoriesProduct;
import com.bman.Models.Category;
import com.bman.Models.Product;
import com.bman.Services.CategoryService;
import com.bman.Services.CpService;
import com.bman.Services.ProductService;

@Controller
public class ProductController {
	private final ProductService productService;
	private final CategoryService categoryService;
	private final CpService cpService;
	
	public  ProductController(ProductService productService, CategoryService categoryService, CpService cpService) {
		this.cpService = cpService;
		this.productService = productService;
		this.categoryService = categoryService;
	}

	
	@RequestMapping("/products/new")
	public String pIndex(@ModelAttribute("Product")Product product) {
		return "pIndex.jsp";
	}
	
	@PostMapping("/product")
	public String createProduct(@Valid @ModelAttribute("Product")Product product, BindingResult result, @RequestParam(value="name") String name, Model model){
		Product pro = productService.search(name);
		if(result.hasErrors()) {
			return "pIndex.jsp";
		}
		else if(pro != null) {
			model.addAttribute("error", "This product already exist");
			return "pIndex.jsp";
		}
		else {
			productService.addProduct(product);
			return "redirect:/products/new";
		}
	}
	
	@RequestMapping("/products/{id}")
	public String product(@ModelAttribute("CategoriesProduct") CategoriesProduct categories, @ModelAttribute("Product")Product product,Model model, @PathVariable(value="id") Long  id) {
		Product pro = productService.findProduct(id);
		List<Category> cats = categoryService.allCategory();
		model.addAttribute("categories", cats);
		model.addAttribute("product", pro);
		return "product.jsp";
	}
	@PostMapping("/addcat")
	public String addcat(@Valid @ModelAttribute("CategoriesProduct") CategoriesProduct categories, BindingResult result) {
		if(result.hasErrors()) {
			return "product.jsp";
		}
		else {
			cpService.cpLink(categories);
			return "redirect:/products/new";
		}
	}
}
