package com.bman.Controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bman.Models.CategoriesProduct;
import com.bman.Models.Category;
import com.bman.Models.Product;
import com.bman.Services.CategoryService;
import com.bman.Services.CpService;
import com.bman.Services.ProductService;

@Controller
public class CategoryController {
	private final ProductService productService;
	private final CategoryService categoryService;
	private final CpService cpService;
	
	public  CategoryController(ProductService productService, CategoryService categoryService, CpService cpService) {
		this.cpService = cpService;
		this.productService = productService;
		this.categoryService = categoryService;
	}

	
	@RequestMapping("/categories/new")
	public String pIndex(@ModelAttribute("Category")Category category) {
		return "cIndex.jsp";
	}
	
	@PostMapping("/category")
	public String createProduct(@Valid @ModelAttribute("Category")Category category, BindingResult result, @RequestParam(value="name") String name, Model model){
		Category cat = categoryService.search(name);
		if(result.hasErrors()) {
			return "cIndex.jsp";
		}
		else if(cat != null) {
			model.addAttribute("error", "This already exist");
			return "cIndex.jsp";
		}
		else {
			categoryService.addCategory(category);
			return "redirect:/categories/new";
		}
	}
	@RequestMapping("/categories/{id}")
	public String category(@ModelAttribute("CategoriesProduct") CategoriesProduct categories, @ModelAttribute("Category")Category category,Model model, @PathVariable(value="id") Long  id) {
		Category cat = categoryService.findCategory(id);
		List<Product> pros = productService.allCategory();
		model.addAttribute("products", pros);
		model.addAttribute("category", cat);
		return "category.jsp";
	}
	@PostMapping("/addprod")
	public String addcat(@Valid @ModelAttribute("CategoriesProduct") CategoriesProduct categories, BindingResult result) {
		if(result.hasErrors()) {
			return "category.jsp";
		}
		else {
			cpService.cpLink(categories);
			return "redirect:/categories/new";
		}
	}
}
